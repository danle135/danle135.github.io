var message = 'hi'
console.log(message)